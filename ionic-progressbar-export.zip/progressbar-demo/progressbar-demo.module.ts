import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ProgressbarDemoPage } from './progressbar-demo.page';
export { ProgressbarDemoPage } from './progressbar-demo.page';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ],
  declarations: [ProgressbarDemoPage]
})
export class ProgressbarDemoPageModule { }