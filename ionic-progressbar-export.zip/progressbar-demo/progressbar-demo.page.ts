import { Component, OnInit } from '@angular/core';

@Component({

  templateUrl: './progressbar-demo.page.html',
  styleUrls: ['./progressbar-demo.page.scss'],
})
export class ProgressbarDemoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}