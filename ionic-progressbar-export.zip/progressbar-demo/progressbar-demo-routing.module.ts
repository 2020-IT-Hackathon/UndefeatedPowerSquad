import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { ProgressbarDemoPage, ProgressbarDemoPageModule } from './progressbar-demo.module';
const routes: Routes = [
    {
        path: '',
        component: ProgressbarDemoPage
    }
];
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        ProgressbarDemoPageModule,
        RouterModule.forChild(routes)
    ]
})
export class ProgressbarDemoRoutingModule { }