import { Component, OnInit } from '@angular/core';
@Component({
  templateUrl: './textarea-demo.page.html',
  styleUrls: ['./textarea-demo.page.scss'],
})
export class TextareaDemoPage implements OnInit {

  minimalTextArea = {
    value: '',
    maxlength: 200
  };

  labeledTextArea = {
    value: '',
    maxlength: 200
  };

  requiredTextArea = {
    value: '',
    maxlength: 200
  };

  constructor() { }
  ngOnInit() {}
}
