# Textarea
Text Areas are styled through CSS properties and controlled with HTML tags. [Get more information from Ionic's Textarea Documentation](https://ionicframework.com/docs/api/textarea)  

## IE11/Edge fix

Some `IE11`/`Edge` users have reported issues via (insert github link here?) that text will sometimes be typed backwards within an `ion-textarea`. 

The following directive may be used to fix that:

```typescript
import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: 'ion-textarea'
})
export class IonTextareaIedgeFixDirective {

  constructor() { }

  @HostListener("ionFocus", ["$event"])
  moveCursorToEnd(event) {
    const isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
    if (isIEOrEdge) {
      const textarea: HTMLTextAreaElement = event.target.querySelector("textarea");
      const existingText = textarea.value;
      if (textarea.value.length === 0) {
        textarea.value = 'a';
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);
        textarea.value = '';
      } else {
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);
        textarea.value = '';
        textarea.value = existingText;
      }
    }
  }
}
```
