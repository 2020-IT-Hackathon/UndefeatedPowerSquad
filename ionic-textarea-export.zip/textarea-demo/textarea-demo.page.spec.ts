import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TextareaDemoPage } from './textarea-demo.page';
describe('TextareaDemoPage', () => {
  let component: TextareaDemoPage;
  let fixture: ComponentFixture<TextareaDemoPage>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextareaDemoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextareaDemoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
