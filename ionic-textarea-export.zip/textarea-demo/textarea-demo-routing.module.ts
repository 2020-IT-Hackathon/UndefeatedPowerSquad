import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TextareaDemoPage, TextareaDemoPageModule } from './textarea-demo.module';
const routes: Routes = [
    {
        path: '',
        component: TextareaDemoPage
    }
];
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        TextareaDemoPageModule,
        RouterModule.forChild(routes)
    ]
})
export class TextareaDemoRoutingModule { }
