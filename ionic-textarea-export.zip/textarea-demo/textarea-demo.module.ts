		
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TextareaDemoPage } from './textarea-demo.page';
export { TextareaDemoPage } from './textarea-demo.page';
import { IonTextareaIedgeFixDirective } from '../../common/directives/ion-textarea-iedge-fix/ion-textarea-iedge-fix.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ],
  declarations: [TextareaDemoPage, IonTextareaIedgeFixDirective]
})
export class TextareaDemoPageModule { }
