# Searchbar
The searchbar component is a text input which will automatically wait a set amount of time after the user has finished typing before firing a change event. The amount of time in milliseconds the input will wait can be controlled via the `debounce` attribute.

Please see the offical [Ionic Searchbar Docs](https://ionicframework.com/docs/api/searchbar) for more information.

## Loading Results

The code in this demo uses mock data.

Typically, when implementing a search component, the application will take the search text the user has entered and send it to the backend to fetch the results. This process, by nature, is asynchronous. In this demo, we listen for an `ionChange` event from the searchbar, and then load the list of results from a file and filter the results directly in the browser:

```html
<ion-searchbar (ionChange)="loadResults($event)"></ion-searchbar>
```

```js
loadResults(){
  // ... code omitted. Inside the popover component:
  
  // Load all the states from a file
  this.statesService.getStates().then(states => {
    // Filter states directly in memory. Compares by state name lowercase
    // this.searchText is the value of the ion-searchbar
    this.results = states.filter(state => state.name.toLowerCase().indexOf(this.searchText.trim().toLowerCase()) > -1);
    // Indicate that the loading has finished
    this.loading = false;
  });
}
```

During the time the file is downloading, we present some text to indicate to the user the loading state:

```html
<ion-item [hidden]="results?.length">
  <ng-container *ngIf="loading">Loading...</ng-container>
  <ng-container *ngIf="!loading">No States Found</ng-container>
</ion-item>
```