import { Component, OnInit, Input } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { StatesService, State } from '../../common/services/states.service';

@Component({
  template: `
  <div style="overflow: auto; max-height: 200px;">
    <ion-list lines="none">
      <ion-item [hidden]="results?.length">
        <ng-container *ngIf="loading">Loading...</ng-container>
        <ng-container *ngIf="!loading">No States Found</ng-container>
      </ion-item>
      <ion-item *ngFor="let result of results" (click)="selectItem(result.abbreviation)">
        {{result.name}}, {{result.abbreviation}}
      </ion-item>
    </ion-list>
</div>
  `,
})
export class SearchbarPopoverComponent implements OnInit {

  // The searchText which is set by the SearchbarDemoPage
  @Input()
  searchText: string;
  // The list of states which match the search
  results: State[];
  // An indicator that this omponent has not yet finishes loading the results from the backend
  loading = true;

  constructor(
    public popoverController: PopoverController,
    private statesService: StatesService
  ) { }

  ngOnInit() {
    this.statesService.getStates().then(states => {
      // Filter states directly in memory. Compares by state name lowercase
      this.results = states.filter(state => state.name.toLowerCase().indexOf(this.searchText.trim().toLowerCase()) > -1);
      // Indicate that the loading has finished
      this.loading = false;
    });
  }

  selectItem(selectedItem: string) {
    this.popoverController.dismiss(selectedItem); //Alert the parent component that the user has selected a value
  }

}
@Component({
  selector: 'app-searchbar-demo.page',
  templateUrl: './searchbar-demo.page.html',
  styleUrls: ['./searchbar-demo.page.scss']
})
export class SearchbarDemoPage implements OnInit {

  searchbarValues: { [s: string]: string } = {};
  // A boolean to indicate that the change event was triggered
  // programatically, and therefore we don't need need to fire another event
  skipNextEvent: boolean;
  types = ['Popover'];

  constructor(
    public popoverController: PopoverController
  ) { }

  async presentPopover(ev: CustomEvent) {

    // If the user didn't enter any value, do not present any popover
    if (!ev.detail.value || ev.detail.value.trim() === '') {
      return;
    }

    const searchbarType = ev.target['id'].replace('sb-', '');

    // If we triggered the last value change, do not show the popover
    if (this.skipNextEvent) {
      this.skipNextEvent = false;
      return;
    }

    const popover = await this.popoverController.create({

      component: SearchbarPopoverComponent,
      event: ev,
      translucent: true,
      showBackdrop: false,
      componentProps: {
        searchText: ev.detail.value //will set the searchtext on the SearchbarPopoverComponent
      }

    });

    popover.onDidDismiss().then(event => {
      console.log(event.data); // Data will be undefined if the user hit the escape key or clicked outside of the popover
      this.searchbarValues[searchbarType] = event.data || this.searchbarValues[searchbarType];
      this.skipNextEvent = true;
    });

    return await popover.present();

  }

  ngOnInit() {
  }
}
