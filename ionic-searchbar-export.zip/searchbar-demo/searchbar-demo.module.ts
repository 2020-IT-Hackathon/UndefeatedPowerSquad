import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, PopoverController } from '@ionic/angular';
import { StatesService } from '../../common/services/states.service'; // Demo Data
import { SearchbarDemoPage, SearchbarPopoverComponent } from './searchbar-demo.page';
export { SearchbarDemoPage, SearchbarPopoverComponent } from './searchbar-demo.page';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ],
  entryComponents: [SearchbarPopoverComponent],
  declarations: [SearchbarDemoPage, SearchbarPopoverComponent],
  exports: [SearchbarDemoPage, SearchbarPopoverComponent],
  providers: [StatesService]// Demo data only
})
export class SearchbarDemoPageModule { }
